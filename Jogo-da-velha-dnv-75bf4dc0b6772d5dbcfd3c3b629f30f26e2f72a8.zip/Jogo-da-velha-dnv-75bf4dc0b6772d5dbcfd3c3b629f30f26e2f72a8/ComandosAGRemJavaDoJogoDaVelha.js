const q = document.querySelectorAll(".QuadradinDoJogo");

let turno = (Math.random>0.5)?
"O":"X";

let gokuSS4 = ["","","","","","","","",""];
q.forEach((QuadradinDoJogo, index)=>{
    QuadradinDoJogo.addEventListener("click",()=>{
        console.log(QuadradinDoJogo.id);
        alert(`Você clicou no Quadradinho ${QuadradinDoJogo.id}`)
       // salvarNaMatrix(q.id)
    });
});